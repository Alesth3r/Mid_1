//Name: Alesther Duran Huanca
//Program Description: Adding Test Scores to an Array
//Date: 3/31/2022
// check chapter 3, pag 115 
"use strict"

const names = ["Ben", "Joel", "Judy", "Anne"];
const scores = [88, 98, 77, 88];

const $ = selector => document.querySelector(selector);

const addScore = () => {
	// get user entries
	const name = $("#name").value;
	const score  = parseInt( $("#score").value );
	let isValid = true; 

    
    // check entries for validity
    if (name == "") {
		$("#name").nextElementSibling.textContent = "This field is required.";
		isValid = false;
	} else {
		$("#name").nextElementSibling.textContent = "";
	}
	
	if (isNaN(score) || score < 0 || score > 100) {
		$("#score").nextElementSibling.textContent = "You must enter a valid score.";
		isValid = false;
	} else {
		$("#score").nextElementSibling.textContent = "";
	}
	
	if (isValid) {
		names[names.length] = name;
		scores[scores.length] = score;
	    $("#name").value = "";
		$("#score").value = "";
	}
    $("#name").focus();
};
// write the scores to the screen in the text area 
const display_scores = () =>{
	// loop through the array and create a new line for each entry
	for (var i = 0; i <= names.length - 1; i++ ) {
		$("#scores_display").value += names[i] + " " + scores[i] + "\n";
	}
}

document.addEventListener("DOMContentLoaded", () => {
	$("#add").addEventListener("click", addScore);
	$("#display_scores").addEventListener("click", display_scores);
	$("#name").focus();
});

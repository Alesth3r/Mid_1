//Name: Alesther Duran Huanca
//Program Description: Converting Temperatures from Farenheit to Celcius
//Date: 3/31/2022
"use strict";
const $ = selector => document.querySelector(selector);
// initilize the starting values for the screen
var fahrenheitConvert = false;
var celsiusConvert = true;
var convertMe  = 0;

/*********************
*  helper functions  *
**********************/
const calculateCelsius = temp => (temp-32) * 5/9;
const calculateFahrenheit = temp => temp * 9/5 + 32;

const toggleDisplay = (label1Text, label2Text) => {
	// clear all entries when the focus change
	// initialize the vulues
	$('#degrees_computed').value = "";
	$('#degrees_entered').value = "";
	// check for which conversion is being entered and 
	// make the screen show the type
	if(label1Text == "Enter F degrees:"){
		
		fahrenheitConvert = false;
		celsiusConvert = true;	
		$("#degree_label_1").innerHTML = "Enter F degrees:";
		$("#degree_label_2").innerHTML = "Degrees Celsius:";
	}
	if(label1Text == "Enter C degrees:"){
		
		celsiusConvert = false;
		fahrenheitConvert = true;
		$("#degree_label_1").innerHTML = "Enter C degrees:";
		$("#degree_label_2").innerHTML = "Degrees Fahrenheit:";
	}
	
	
}

/****************************
*  event handler functions  *
*****************************/
const convertTemp = () => {   
	// start variable for storing the temp
	var myTemp = $('#degrees_entered').value;
	//check which conversion type to use
	if(celsiusConvert == true){
		$('#degrees_computed').value = calculateFahrenheit(myTemp);
	}
	if(fahrenheitConvert == true){
		$('#degrees_computed').value = calculateCelsius(myTemp);
	}
	
};

const toCelsius = () => toggleDisplay("Enter F degrees:", "Degrees Celsius:");
const toFahrenheit = () => toggleDisplay("Enter C degrees:", "Degrees Fahrenheit:");

document.addEventListener("DOMContentLoaded", () => {
	// add event handlers
	$("#convert").addEventListener("click", convertTemp);
    $("#to_celsius").addEventListener("click", toCelsius);
    $("#to_fahrenheit").addEventListener("click", toFahrenheit);
	
	// move focus
	$("#degrees_entered").focus();
});
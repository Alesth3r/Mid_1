"use strict";
//Name: Alesther Duran Huanca
//Program Description: Develop an application that calculates the sales tax and invoice 
//total after the user enters the subtotal and tax rate.
//Date: 4/1/2022
//Chapter 5 , pages 163, 165

const $ = selector => document.querySelector(selector);

const calculateTax = () => {
    const amount = $("#subtotal").value;
    const tax = $("#tax_rate").value;
    var totalTax = amount * (tax/100);
    var mainTotal = Number(amount) + Number(totalTax) ;
    alert(" total is "+totalTax);
    $("#sales_tax").value = totalTax;
    $("#total").value = mainTotal;

};

const clearValues = () => {
};

document.addEventListener("DOMContentLoaded", () => {
	$("#calculate").addEventListener("click", calculateTax);
	$("#clear").addEventListener("click", clearValues);
	$("#subtotal").focus();
});


